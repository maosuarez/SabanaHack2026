# Especificación — Escena 3D de invernadero de rosas (HTML)

Referencias visuales en `referencias/`, junto a este archivo:
- `foto_*.jpg`: fotos reales del reto, tomadas desde el camino mirando hacia arriba. Hay una por clase y una del camino.
- `video_*.jpg`: frames del camino, de la vista lateral y de la cortadora con su carro.
- `capsula_cht_*.jpg`: frames de la cápsula de capacitación con los 3 patrones de forma (triangular, cilindro, copa) y los criterios de color y tamaño.

Objetivo: tener un **campo de rosas simulado** que se vea como en las fotos y videos del reto. Sirve para:
1. Prototipar la capacitación en VR y en realidad mixta.
2. Probar el modelo de visión sobre capturas sintéticas.
3. Hacer la demo cuando no haya rosas reales.

Cada dato indica de dónde sale:
- **[sesión]**: lo dijeron los expertos de la finca.
- **[ficha]**: ficha técnica del reto.
- **[video]**: videos de apoyo (la cápsula de CHT y las tomas del pasillo); ver `referencias/`.
- **[foto]**: dataset.
- **[estimado]**: lectura visual nuestra, ajustable.

## 1. Restricciones generales
- Un solo archivo `.html` autocontenido. Three.js por CDN con la versión fijada (por ejemplo `three@0.160.0`). **Geometría procedural**: sin modelos externos ni texturas descargadas. Las texturas se generan con canvas o shaders.
- En la escena **solo hay rosas**: ningún otro cultivo, sin personas ni animales. Los únicos elementos que no son plantas son la infraestructura del invernadero, descrita en la sección 3.
- Debe correr fluido en un portátil común y, como meta, en el navegador de la Quest 3: instancing y LOD obligatorios.
- Opcional: un botón "Entrar en VR" con WebXR, para probarlo en la Quest.

## 2. Layout del invernadero
- **Al menos un camino largo** recto entre dos camas, que es la vista de `referencias/video_camino_y_lateral.jpg`. Se puede repetir el patrón cama–camino–cama hacia los lados para dar sensación de escala.
- **Cama**: aproximadamente **1 m de ancho × 32 m de largo** **[sesión]**, con **unas 400 plantas en doble hilera** **[sesión]**. Eso equivale a unas 12,5 plantas por metro lineal de cama, es decir, unas 6 por metro en cada hilera, con una separación de 15 a 17 cm.
- **Camino**: de **tierra oscura, compactada y húmeda**, de **0,5 a 0,7 m de ancho** **[video][estimado]**. Es angosto: las plantas de ambos lados casi se tocan por encima. Bordes irregulares con hojas caídas.
- Al fondo del camino hay un **punto de fuga muy luminoso**, la salida o el cabezal del invernadero **[video]**.
- El sustrato de la cama es tierra o cascarilla de arroz quemada (gris oscura) **[sesión]**.

## 3. Estructura del invernadero (solo como contexto)
- **Techo de plástico blanco translúcido** que difunde la luz y aparece muy brillante en todas las tomas hacia arriba. Altura de cumbrera de **4 a 5 m** **[foto][estimado]**: el techo se ve de 1,5 a 2,5 m por encima de las flores.
- **Cerchas y arcos de tubo metálico galvanizado** gris, cruzando por encima de las camas cada 3 a 4 m **[foto][video]**.
- **Postes verticales de madera** (eucalipto, sin pintar) en las cabeceras y cada cierto tramo dentro de la cama **[foto]**.
- **Cuerdas y alambres guía** horizontales a lo largo de la cama, en 3 o 4 alturas, para mantener los tallos derechos **[sesión][video]**. Son líneas blancas o grises muy finas, visibles en diagonal en el video del carro.
- **Ventiladores de circulación** colgados de la estructura: cilindros metálicos de unos 50 cm, cada 10 a 15 m **[video]**.
- **Detalles opcionales**: un **carro de corte** estático en el camino (estructura metálica baja con una **canasta plástica azul**), como en `referencias/video_corte_con_carro.jpg`.

## 4. La planta de rosa
- **Altura total de la planta: 1,8 a 2,4 m**. Las flores quedan **por encima de la cabeza** del cortador **[video][foto]**. En el video, la cortadora (unos 1,60 m) estira el brazo hacia arriba para alcanzarlas.
- **Zona de corte**: de **110 a 140 cm** del suelo **[sesión]**. Ahí se corta el tallo. Los tallos florales nacen de esa zona y miden de **47 cm a 80 cm** con la cabeza **[sesión]**. Por eso los botones quedan entre 1,6 y 2,3 m.
- **Estructura**:
  - Una base leñosa (los "basales") de la que salen varios tallos.
  - Los tallos florales son **largos, rectos y casi verticales**, verdes y a veces con tonos rojizos. Tienen pocas espinas pequeñas.
  - Muchos tallos por planta. El conjunto de la cama forma un **muro denso de follaje**, sin huecos, desde el suelo hasta arriba **[video]**.
- **Hojas**:
  - **Compuestas, con 5 folíolos** (la "hoja verdadera" **[sesión]**), de borde aserrado y verde medio a oscuro, algo brillantes.
  - Entre 4 y 8 hojas por tallo floral, alternas.
  - **El brote nuevo es rojizo o bronce**: muchas hojas jóvenes cobrizas y rojas, sobre todo arriba **[foto][video]**. Es un rasgo muy visible en las tomas y **no debe omitirse**.
  - Algunas hojas viejas tienen bordes amarillos o secos.
- **Densidad de botones**: **muchos**. Cada metro lineal de cama visible desde el camino debe tener entre 8 y 15 botones en distintos estados, a distintas alturas (1,6 a 2,3 m) y a distintas profundidades. Algunos quedan detrás de hojas, con oclusión parcial.
- **Tallos ciegos**: entre el 5 % y el 10 % de los tallos terminan sin botón **[sesión]**.

## 5. Modelos de la flor — variedad Freedom (roja)
Cada botón es una **instancia con un parámetro `estado`** que controla la forma, el color, el tamaño y los sépalos. Debe ser una interpolación continua, para poder generar estados intermedios. Cada instancia guarda su etiqueta real.

Pieza común a todos los estados: un **cáliz de 5 sépalos** verdes, largos y estrechos, con **apéndices laterales plumosos** (lóbulos finos en el borde) **[video]**, sobre un **pedúnculo** verde de 5 a 10 cm.

### 5.1 INMADURO — no cortar
Hay que modelar los subestados de crecimiento **[sesión]**:
| Subestado | Aspecto |
|---|---|
| Arroz | Botón verde de unos 5 mm |
| Arveja | Esfera verde de unos 1 cm |
| Garbanzo | Bolita verde de 1,5 a 2 cm, totalmente cubierta por los sépalos |
| Raya de color | Botón ovoide de 2,5 a 3,5 cm, verde, con una **rayita roja** asomando en la punta entre los sépalos |
| Cerrado (punto 1–2) | Botón de 3,5 a 4,5 cm. Los sépalos están **pegados** a los pétalos **[ficha]**. Silueta en **"patrón triangular"**: estrecha arriba y **termina en punta** **[video][sesión]**. Rojo **más oscuro**, granate **[ficha]**. Cabeza pequeña |

Visto **desde abajo**, que es la vista del cortador, el botón se ve como un cono que termina en punta, rodeado de sépalos verdes ajustados.

### 5.2 ÓPTIMO — punto de corte (punto 3 en Freedom **[ficha]**)
- Cabeza de **5 a 6 cm** de alto **[sesión: poscosecha exige 5 cm o más]**.
- **Silueta en "patrón de copa"**: trapecio invertido, más ancho arriba que abajo **[video][ficha]**.
- **Sépalos separados**, abiertos hacia afuera o reflejos (doblados hacia abajo). Desde abajo se ven como una estrella verde alrededor de la base.
- Los pétalos externos empiezan a soltarse en el borde superior, con el borde algo curvado hacia afuera. Por arriba, **el caracol está definido y deja ver el centro**: espiral apretada de pétalos **[ficha][video]**.
- **Rojo vivo e intenso**: rojo carmín y aterciopelado (referencia aproximada `#B5121B` a `#C8102E`, **[estimado]**). No debe verse pálido ni granate.

### 5.3 SOBREABIERTO — ya pasó el punto
- **Tres o más pétalos externos desprendidos** y abiertos hacia afuera **[sesión: "entre 2 y 3 pétalos abiertos ya está abierto"]**.
- La forma de copa se pierde: la flor queda **más ancha que alta**, de 7 a 10 cm de diámetro. El centro está expuesto y las capas de pétalos sueltas y visibles.
- Los sépalos están completamente reflejos hacia abajo.
- El color sigue siendo rojo, pero los bordes externos pueden verse un poco más oscuros o maltratados.

### Distribución sugerida en la escena **[estimado]**, configurable
| Estado | % de botones |
|---|---|
| Inmaduro: arroz, arveja y garbanzo | 25 % |
| Inmaduro: raya de color y cerrado | 40 % |
| Óptimo | 25 % |
| Sobreabierto | 10 % |

La mayoría de los botones está inmadura porque las flores en punto se cortan a diario **[sesión]**. Las óptimas deben estar **mezcladas** con inmaduras muy parecidas, en particular con las cerradas, porque cortarlas antes de tiempo es el error más común **[ficha]**.

## 6. Cámara, luz y atmósfera
- **Primera persona** dentro del camino. Altura de los ojos: **1,55 a 1,65 m**. FOV de 70 a 75°.
- Controles: WASD o flechas para caminar a lo largo del camino y ratón para mirar. **El pitch debe permitir mirar bastante hacia arriba**, hasta unos 70°, porque **la vista principal es de abajo hacia arriba** **[sesión][foto]**.
- **Iluminación**:
  - Cielo nublado difundido por el plástico: luz hemisférica blanca y fría arriba, con rebote verde abajo.
  - **Contraluz fuerte**: el techo se ve casi blanco y los botones y las hojas aparecen algo más oscuros, en silueta, contra el fondo. Es la condición difícil del dataset **[foto]**, y **no debe "corregirse"** con luces frontales.
  - Sin sombras duras. Oclusión ambiental o niebla suave para dar profundidad al camino.
- Niebla ligera hacia el fondo, que se combina con el punto de fuga luminoso.

## 7. Interacción para capacitación y datos
- **Seleccionar un botón**, con clic o raycast desde el centro de la vista: se resalta y se muestra un panel.
- **Modo Entrenar**:
  1. La persona elige primero "Cortar" o "No cortar".
  2. Después se revela el estado real y el porqué, con los tres criterios de la finca:
     - **Color**: vivo/definido vs. oscuro/pálido.
     - **Forma**: punta/triángulo, cilindro o copa.
     - **Tamaño**: 5 cm o más.
  3. Al final, puntaje y errores frecuentes.
- **Toggle de depuración**: colorea cada botón según su etiqueta real (por ejemplo, inmaduro azul, óptimo verde, sobreabierto naranja).
- **Exportar captura**: guarda un PNG de la vista y un JSON con las cajas 2D proyectadas y la etiqueta de cada botón visible, para generar datos sintéticos.
- **Semilla aleatoria** configurable, para que la escena sea reproducible.

## 8. Criterios de aceptación ("se parece a las fotos")
1. Al mirar hacia arriba desde el camino, la composición se parece a `referencias/foto_*.jpg`: techo blanco, follaje verde y rojizo, varios botones rojos pequeños a distintas distancias y alambres finos.
2. Al mirar al frente, se parece a `referencias/video_camino_y_lateral.jpg` (los primeros frames): dos muros altos de rosas, un camino de tierra angosto y un fondo luminoso.
3. Una persona que vio la cápsula de CHT distingue a simple vista un botón en punta, uno en copa y uno sobreabierto **cuando lo ve de cerca**, y le cuesta un poco más hacerlo **de lejos y a contraluz**, igual que en el campo real.
4. En el campo visual hay más de 100 botones y la escena no baja de unos 30 fps en un portátil.
